<?php ob_start();?>
<?php
session_start();
$id = $pwd = "";
if(isset($_SESSION['username'])){
    $id=$_SESSION['username'];
    $pwd=$_SESSION['password'];
}
?>
<?php
    // 设置编码
    header("Content-type:text/html;charset=utf-8");
    echo '
        <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>个人信息</title>
        </head>
        <style type="text/css">
        body{
                  background-image: url(1.jpg);
              }
        .wrapper {width: 1000px;margin: 20px auto;}
        h2 {text-align: center;}
        .HOME {margin-bottom: 20px;}
        .HOME a {text-decoration: none;color: #fff;background-color: green;padding: 6px;border-radius: 5px;}
        td {text-align: center;}
        </style>
        <body>
            <div class="wrapper">
                <h2>Personal Information</h2>
                <div class="HOME">
                    <a href="../Controller/admin_page.php">HOME</a>
                </div>
                <table width="960" border="1">
                    <tr>
                	<th>  账号  </th>
                	<th>  姓名  </th>
                	<th>  性别  </th>
                	<th>  专业  </th>
                	<th>  年级  </th>
                	<th>系统密码</th>
                    <th>校园卡卡号</th>
                    <th>校园卡密码</th>
                    <th>校园卡状态</th>
                	</tr>';
 
                    // 引入配置信息
                	require "dbConfig.php";
                	
                	// 连接mysql
                	$link = @mysqli_connect(HOST, USER, PASS, DBNAME) or die("ERROR: CANNOT CONNECT TO DATABASE!");
                	
                	// 编码设置
                	mysqli_set_charset($link,'utf-8');
                 	$sql = "SELECT * FROM students";
                	$result = mysqli_query($link, $sql);
                	$readersNum = mysqli_num_rows($result);
                	for($i=0; $i<$readersNum; $i++){
                	    $row = mysqli_fetch_assoc($result);
                	    echo "<tr>";
                	    echo "<td>{$row['s_id']}</td>";
                	    echo "<td>{$row['s_name']}</td>";
                	    echo "<td>{$row['sex']}</td>";
                	    echo "<td>{$row['academy']}</td>";
                	    echo "<td>{$row['grade']}</td>";
                	    echo "<td>{$row['password']}</td>";
                	    echo "<td>{$row['card_id']}</td>";
                	    echo "<td>{$row['c_psw']}</td>";
                	    if($row['reset']==0)
                	       echo "<td>正常</td>";
                	    else 
                	        echo "<td>挂失</td>";
                	    echo "<td>
                                <a href='javascript:del({$row['s_id']})'>删除</a>
                                <a href='editinformation.php?s_id={$row['s_id']}'>修改</a>
                              </td>";
                	    echo "</tr>";
                	}
                	mysqli_free_result($result);
                	mysqli_close($link);
                	header("Content-type:text/html;charset=utf8");
                	echo '
                 </table>
            </div>
 <script type="text/javascript">
                function del (s_id) {
                    if (confirm("删除?")){
                        window.location = "delete.php?s_id=" + s_id;
                    }
                }
            </script>
        </body>
    </html>
                
    ';
   ob_end_flush();
?>