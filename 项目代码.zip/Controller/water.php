<?php ob_start();?>
<?php
error_reporting(E_ERROR);
ini_set("display_errors","Off");
session_start();
$s_id='';
if(isset($_SESSION['username'])){
    $s_id=$_SESSION['username'];
}
?>
<?php
// 处理增加操作的页面
require "dbConfig.php";
// 连接mysql
$link = @mysqli_connect(HOST, USER, PASS, DBNAME) or die("ERROR: CANNOT CONNECT TO DATABASE!");
// 编码设置
mysqli_set_charset($link,'utf8');

echo '<html>
    <head lang="en">
    <meta charset="UTF-8">
    <title>Add</title>
    <link rel="stylesheet" type="text/css">
    </head>
    <style type="text/css">
    #lunkuo{
    position: absolute;
    top: 35%;/*顶部到元素*/
    left:30%;
    width: 40%;
    height:420px;
    margin-top:0;/*边缘到底部*/
    text-align-last: center;
    line-height:30px;
}
body{
    background-image: url(1.jpg);

} 
.wrapper {width: 1100px;margin: 20px auto;}
        h2 {text-align: center;}
       
        .HOME {margin-bottom: 20px;}
        .HOME a {text-decoration: none;color: #fff;background-color: green;padding: 6px;border-radius: 5px;}
</style>
<body>
<div class="wrapper">
               
                <div class="HOME">
                    <a href="../Controller/page.php">主页面</a>
                </div>
</div>
<div id="lunkuo">
<form action=# method="post" >


<td><span style="display:inline-block;width:90px;">宿舍号：</span></td><td><input type="text" name="number" /></td><br>
<td><span style="display:inline-block;width:90px;">充值金额：</span></td><td><input type="text" name="money" /></td><br>

<span style="display:inline-block;width:90px;"></span><input type="submit" value="Submit">
</form>
</div>
</body>
</html>
';

if(isset($_POST['number'])&&isset($_POST['money']))
{
    $number1=$_POST['number'];
    $money1=$_POST['money'];
    
    if(!$number1||!$money1)
        echo '<script>alert("宿舍号/充值金额不能为空!");parent.location.href="../Controller/water.php";</script>';
        else
        {
            
            
            
            //     else
                //     {
            $sql3 = mysqli_query($link, "SELECT * FROM card where s_id='$s_id'");  //根据餐时编号找对应信息
            $result1=mysqli_fetch_assoc($sql3);
            $r_sum=$result1['remaining_sum'];
            $r_sum=$r_sum-$money1;
            if($r_sum<0)
                echo '<script>alert("校园卡余额不足!");parent.location.href="../Controller/water.php";</script>';
                else
                {
//                     echo $number1;
                    $sql3 = mysqli_query($link, "SELECT * FROM water where number='$number1'");  //根据餐时编号找对应信息
                    $s=mysqli_num_rows($sql3);
                    if($s>0)
                    {
                        $result=mysqli_fetch_assoc($sql3);
                        $money2=$result['money']+$money1;
                        $sql = "UPDATE water SET money='$money2' where number = '$number1'";
                        $result=mysqli_query($link, $sql);
                        
                        //扣除校园卡余额
                        $sql5 = mysqli_query($link, "update card set remaining_sum='$r_sum' where s_id='$s_id'");
                        
                        //生成账单编号
//                         $num=1000;
//                         $sql2=mysqli_query($link,"SELECT * FROM bill");
//                         $billnum = mysqli_num_rows($sql2);
//                         $num=$num+$billnum;
                        
                        //生成账单信息
                        $card_id=$result1['card_id'];
                        $date=date('y-m-d h:i:s'); //当前时间
                        
                        $name="水费";
                        $shangjia="公寓水控";
                        $sql = "INSERT INTO bill VALUES (NULL,'$card_id','$date','$name','$money1','$shangjia','$r_sum')";
                        mysqli_query($link, $sql);
                        mysqli_close($link);
                        echo '<script>alert("充值成功!");parent.location.href="../Controller/water.php";</script>';
                    }
                    else
                    {
                        $result=mysqli_fetch_assoc($sql3);
                        $money2=$result['money']+$money1;
                        $sql = "insert water values('$number1','$money1')";
                        $result=mysqli_query($link, $sql);
                        
                        //扣除校园卡余额
                        $sql5 = mysqli_query($link, "update card set remaining_sum='$r_sum' where s_id='$s_id'");
                        
                        //生成账单编号
//                         $num=1000;
//                         $sql2=mysqli_query($link,"SELECT * FROM bill");
//                         $billnum = mysqli_num_rows($sql2);
//                         $num=$num+$billnum;
                        
                        //生成账单信息
                        $card_id=$result1['card_id'];
                        $date=date('y-m-d h:i:s'); //当前时间
                        $name="水费";
                        $shangjia="公寓水控";
                        $sql = "INSERT INTO bill VALUES (NULL,'$card_id','$date','$name','$money1','$shangjia','$r_sum')";
                        mysqli_query($link, $sql);
                        mysqli_close($link);
                        echo '<script>alert("充值成功!");parent.location.href="../Controller/water.php";</script>';
                    }
                }
}
    
//     }
//     else
//         echo '<script>alert("请输入校园卡密码!");parent.location.href="../Controller/guashi.php";</script>';
}
?>