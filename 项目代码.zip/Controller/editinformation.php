 <?php
    // 设置编码
    header("content-type:text/html;charset=utf-8");
    // 引入配置信息
    require "dbConfig.php";
    // 连接mysql
    $link = @mysqli_connect(HOST, USER, PASS, DBNAME) or die("ERROR: CANNOT CONNECT TO DATABASE!");
    
    // 获取传递的isbn,并显示原先的值ֵ
    $s_id = $_GET['s_id'];
    $sql = mysqli_query($link, "SELECT * FROM students WHERE s_id='$s_id' ");
    $old = mysqli_fetch_assoc($sql); 
    echo '
        <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>修改用户信息</title>
        </head>
        <style type="text/css">
        #lunkuo{
				position: absolute;
				top: 35%;/*顶部到元素*/
				left:29%;
				width: 40%;
				height:420px;
				margin-top:0;/*边缘到底部*/		
				text-align-last: center;
				line-height:30px;
			}
        body{
             background-image: url(1.jpg);
             }
        .wrapper {width: 1000px;margin: 20px auto;}
        h2 {text-align: center;}
        td {text-align: center;}
        </style>
        <body>
            <h2>修改用户信息</h2>
            <div id="lunkuo">
                <div  class="add_top">
                	<form action="../Controller/updateinformation.php" method="post" >  
                	    <td><span style="display:inline-block;width:90px;">账号：</span></td><td><input type="text" name="s_id" value="';
                                                        echo $old['s_id'];
                                                        //echo "（账号不能修改）";
                                                        echo '"/onfocus=this.blur()></td><br>
                	    <td><span style="display:inline-block;width:90px;">系统密码：</span></td><td><input type="text" name="password" value="';
                	                                    echo $old['password'];
                	                                    echo '"/></td><br>
                	    <td><span style="display:inline-block;width:90px;">卡密码：</span></td><td><input type="text" name="c_psw" value="';
                	                                    echo $old['c_psw'];
                	                                    echo '"/></td><br>
                	    <td><span style="display:inline-block;width:90px;">卡状态：</span></td><td><input type="text" name="reset" value="';
                	                                    echo $old['reset'];
                	                                    echo '"/></td><br>
                       
                	    <span style="display:inline-block;width:90px;"></span><input type="submit" value="Submit">  
                	</form>  
                </div>
            </div>
            
        </body>
    </html>
                
    ';
?>