<?php
error_reporting(E_ERROR);
ini_set("display_errors","Off");
// 设置编码
header("content-type:text/html;charset=utf-8");
// 引入配置信息
require "dbConfig.php";
// 连接mysql
$link = @mysqli_connect(HOST, USER, PASS, DBNAME) or die("ERROR: CANNOT CONNECT TO DATABASE!");

// 获取修改的信息
$s_id = $_POST['s_id'];
$pwd = $_POST['password'];
$c_psw = $_POST['c_psw'];
$reset = $_POST['reset'];


// 更新数据
$sql = "UPDATE students SET password='$pwd', c_psw='$c_psw', reset='$reset' where s_id = '$s_id'";
$result=mysqli_query($link, $sql);
if(mysqli_affected_rows($link))
{
    echo '<script>alert("修改成功！");parent.location.href="../Controller/information.php";</script>';
}
mysqli_close($link);
//header("Location:information.php");
?>