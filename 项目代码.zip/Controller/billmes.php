<?php ob_start();?>
<?php
session_start();
$userid=$_SESSION['username'];
include ('mysqli_connect.php');
//$clid=$_GET['id'];
// $clid=123;
$s_id="";
if(isset($_SESSION['username'])){
    $s_id=$_SESSION['username'];
}

$sql3 = mysqli_query($dbc, "SELECT * FROM students where s_id='$s_id'");  //根据餐时编号找对应信息
$result1=mysqli_fetch_assoc($sql3);
$clid=$result1['card_id'];


$sqlb="select * from bill where card_id={$clid}";
$resb=mysqli_query($dbc,$sqlb);
//$resultb=mysqli_fetch_array($resb);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="http://cdn.static.runoob.com/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>校园卡管理系统 || 账单信息</title>
    <style>
        body{
            background-image:url(1.jpg);
            background-size: cover;
            background-repeat: no-repeat;
        }
        .wrapper {width: 1100px;margin: 20px auto;}
        h2 {text-align: center;}
       
        .HOME {margin-bottom: 20px;}
        .HOME a {text-decoration: none;color: #fff;background-color: green;padding: 6px;border-radius: 5px;}
       
    </style>
</head>
<body>
<div class="wrapper">
<div class="HOME">
                    <a href="../Controller/page.php">主页面</a>
                </div>
                </div>
<h1 style="text-align: center;color:navajowhite;font-size: 34px;padding-top: 2%;font-family: 华文楷体"><strong>消费信息</strong></h1>
<table  width='100%' class="table table-hover">
    <tr>
        <th>账单编号</th>
        <th>校园卡号</th>
<!--         <th>学号</th> -->
        <th>消费时间</th>
        <th>消费产品</th>
        <th>价格</th>
        <th>商家</th>
        <th>卡内余额</th>

    </tr>
<?php

$Num = mysqli_num_rows($resb);
for($i=0; $i<$Num; $i++){
    $row = mysqli_fetch_assoc($resb);
        echo "<tr>";
        echo "<td>{$row['bill_num']}</td>";
        echo "<td>{$row['card_id']}</td>";
//         echo "<td>{$row["s_id"]}</td>";
        echo "<td>{$row["consume_time"]}</td>";
        echo "<td>{$row["product_name"]}</td>";
        echo "<td>{$row["price"]}</td>";
        echo "<td>{$row['shangjia']}</td>";
        echo "<td>{$row['remaining_sum']}</td>";
        echo "</tr>";
    };

?>
</table>
</body>
</html>
