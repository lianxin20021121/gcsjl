<?php ob_start();?>
<?php
error_reporting(E_ERROR);
ini_set("display_errors","Off");
session_start();
$s_id='';
if(isset($_SESSION['username'])){
    $s_id=$_SESSION['username'];
}
?>
<?php
// 处理增加操作的页面
require "dbConfig.php";
// 连接mysql
$link = @mysqli_connect(HOST, USER, PASS, DBNAME) or die("ERROR: CANNOT CONNECT TO DATABASE!");
// 编码设置
mysqli_set_charset($link,'utf8');

echo '<html>
    <head lang="en">
    <meta charset="UTF-8">
    <title>Add</title>
    <link rel="stylesheet" type="text/css">
    </head>
    <style type="text/css">
    #lunkuo{
    position: absolute;
    top: 35%;/*顶部到元素*/
    left:30%;
    width: 40%;
    height:420px;
    margin-top:0;/*边缘到底部*/
    text-align-last: center;
    line-height:30px;
}
body{
    background-image: url(1.jpg);

} 
.wrapper {width: 1100px;margin: 20px auto;}
        h2 {text-align: center;}
       
        .HOME {margin-bottom: 20px;}
        .HOME a {text-decoration: none;color: #fff;background-color: green;padding: 6px;border-radius: 5px;}
</style>
<body>
<div class="wrapper">
               
                <div class="HOME">
                    <a href="../Controller/page.php">主页面</a>
                </div>
</div>
<div id="lunkuo">
<form action=# method="post" >


<td><span style="display:inline-block;width:90px;">密码：</span></td><td><input type="text" name="psw" /></td><br>

<span style="display:inline-block;width:90px;"></span><input type="submit" value="Submit">
</form>
</div>
</body>
</html>
';
if (isset($_POST['psw']))
{
    $psw = $_POST['psw'];
    if($psw)
    {
        $sql3 = mysqli_query($link, "SELECT * FROM students where s_id='$s_id'");  //根据餐时编号找对应信息
        $result1=mysqli_fetch_assoc($sql3);
        $c_psw=$result1['c_psw'];
        $s=$result1['reset'];
        
        if($psw!=$c_psw)
        {
            //mysqli_close($link);
            echo '<script>alert("校园卡密码错误!");parent.location.href="../Controller/guashi.php";</script>';
        }
        else if($s==1)
            echo '<script>alert("校园卡状态异常!");parent.location.href="../Controller/guashi.php";</script>';
        else
        {
            $sql = "UPDATE students SET reset=1 where s_id = '$s_id'";
            $result=mysqli_query($link, $sql);
            $sql = "UPDATE card SET state=1 where s_id = '$s_id'";
            $result=mysqli_query($link, $sql);
            echo '<script>alert("挂失成功!");parent.location.href="../Controller/page.php";</script>';
        }
            
    }
    else
        echo '<script>alert("请输入校园卡密码!");parent.location.href="../Controller/guashi.php";</script>';
}
?>