<?php
// 处理删除操作的页面
require "dbconfig.php";
// 连接mysql
$link = @mysqli_connect(HOST, USER, PASS, DBNAME) or die("ERROR: CANNOT CONNECT TO DATABASE!");
mysqli_set_charset($link,'utf-8');
//  获取传递的isbn
$s_id = $_GET['s_id'];
$sql = "DELETE FROM students where s_id = {$s_id}";
mysqli_query($link, $sql);
$sql = "DELETE FROM card where s_id = {$s_id}";
mysqli_query($link, $sql);
mysqli_close($link);
header("Location:information.php");
?>