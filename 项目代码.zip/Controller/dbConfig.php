<?php
//mysql配置信息
define("HOST","localhost");
define("USER","root");
define("PASS","123456");
define("DBNAME","schoolcard");
?>