<?php ob_start();?>
<?php
session_start();

$clid="";
if(isset($_SESSION['username'])){
    $clid=$_SESSION['username'];
}
$user_id=$clid;
?>
<?php
// 数据库连接信息
$host = 'localhost';
$user = 'root';
$password = '123456';
$dbName = 'schoolcard';

// 建立数据库连接
$conn = new mysqli($host, $user, $password, $dbName);

// 检测连接是否成功
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 获取post请求中提交的参数
$card_id = $_POST['bankcard_id'];
$card_type = $_POST['bankcard_type'];
$card_password = $_POST['password'];
//echo $card_type;

// 检测输入参数的合法性
if (empty($card_id) || empty($card_type) || empty($card_password)) {
   die('银行卡信息不完整，请填写完整的银行卡信息');
//     echo '<script>alert("银行卡信息不完整，请填写完整的银行卡信息");parent.location.href="../Controller/card_bind.php";</script>';
}

// 检测该用户是否已经绑定过该银行卡类型
if (isCardTypeAlreadyBound($conn, $user_id, $card_type)) {
   die('每个学生每种卡类型最多只能绑定一张，请选择其它银行卡类型');
//     echo '<script>alert("每个学生每种卡类型最多只能绑定一张，请选择其它银行卡类型");parent.location.href="../Controller/card_bind.php";</script>';
}

// 检测该银行卡是否已经存在
$bankcard_info = getCardInfoByCardNumber($conn, $card_id);
if ($bankcard_info == null) {
    die('该银行卡不存在，请检查输入的银行卡信息');
//     echo '<script>alert("该银行卡不存在，请检查输入的银行卡信息");parent.location.href="../Controller/card_bind.php";</script>';
}

// 检测该银行卡是否已经被绑定
if (isCardAlreadyBound($conn, $card_id)) {
    die('该银行卡已经被绑定，请勿重复绑定');
//     echo '<script>alert("该银行卡已经被绑定，请勿重复绑定");parent.location.href="../Controller/card_bind.php";</script>';
}

//检测输入密码是否正确
if($bankcard_info['bc_password']!=$card_password){
    die('输入密码错误');
//     echo '<script>alert("输入密码错误");parent.location.href="../Controller/card_bind.php";</script>';
}

// 向card1表中添加绑定信息
if (!addBoundCardInfo($conn, $user_id, $card_id, $card_type, $bankcard_info['bankcard_money'])) {
    die('添加绑定信息失败，请稍后重试');
//     echo '<script>alert("添加绑定信息失败，请稍后重试");parent.location.href="../Controller/card_bind.php";</script>';
}

echo "恭喜你，绑定银行卡成功！";

// 关闭连接
$conn->close();

/*// 获取当前用户的学号
 function getCurrentUserId() {
 session_start();
 //$userid=$_SESSION['userid'];
 $userid=1;
 }*/

// 检测该用户是否已经绑定过该银行卡类型
function isCardTypeAlreadyBound($conn, $user_id, $card_type) {
    $sql = "SELECT count(*) FROM card_bind WHERE s_id='$user_id' AND bankcard_type='$card_type'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count(*)'] >= 1;
    }
    return false;
}

// 检测银行卡是否已经被绑定
function isCardAlreadyBound($conn, $card_id) {
    $sql = "SELECT count(*) FROM card_bind WHERE bankcard_id='$card_id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count(*)'] >= 1;
    }
    return false;
}

// 向card_bind表中添加绑定信息
function addBoundCardInfo($conn, $user_id, $card_id, $card_type, $money) {
   // echo $card_type;
//    $card_type="中国农商";
    $sql = "INSERT INTO card_bind VALUES ('$user_id', '$card_id', '$card_type', '$money')";
    return $conn->query($sql);
}

// 获取银行卡信息
function getCardInfoByCardNumber($conn, $card_id) {
    $sql = "SELECT bankcard_money, bankcard_type,bc_password FROM bank_card WHERE bankcard_id='$card_id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row;
    }
    return null;
}
