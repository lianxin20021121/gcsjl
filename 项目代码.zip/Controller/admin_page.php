<?php
session_start();
$id="";
if(isset($_SESSION['username'])){
    $id=$_SESSION['username'];
}
?>
<html>
	<title>Document</title>
<head>
<meta charset="UTF-8"> 
<style>
    .header
    {
        padding: 10px;
        text-align: center;
/*         background-image:linear-gradient(to  right,#ededa7,#f99c9c); */
background-color:#9c0c13;
        color: white;
    }
    body{
        background-color: azure;
    }
    img{
        
        width:100%;
        height:400px;
    }
   

h1{
    font-size:40px;
}

/* 底部 */
.footer {
    padding: 30.5px;
    text-align: center;
/*     background-image: linear-gradient(to  right,#ededa7,#f99c9c); */
background-color:#9c0c13;
    position: absolute;
    bottom: 0; 
    width: 1402.5px;
}

h2{
    color:white;
}

/* 导航栏容器 */
.navbar {
  overflow: hidden;
  background-color: #FFF5EE;
  font-family: Arial;

}

/* 导航栏内的链接 */
.navbar a {
  float: left;
  font-size: 20px;
  color: grey;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* 下拉容器 */
.dropdown {
  float: left;
  overflow: hidden;
}

/* 下拉按钮 */
.dropdown .dropbtn {
  font-size: 20px;
  border: none;
  outline: none;
  color: grey;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit; /* 对手机垂直对齐很重要 */
  margin: 0; /* 对手机垂直对齐很重要 */
}

/* 为悬停时的导航栏链接添加背景颜色 */
.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: white;
}

/* 下拉内容（默认隐藏）*/
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #FFF5EE;
  min-width: 100px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* 下拉列表中的链接 */
.dropdown-content a {
  float: none;
  color: grey;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

/* 为悬停时的下拉链接添加灰色背景颜色 */
.dropdown-content a:hover {
  background-color: white;
}

/* 悬停时显示下拉菜单 */
.dropdown:hover .dropdown-content {
  display: block;
}
</style>
</head>
<body OnLoad="swapPic()">
   <div class="header">
    <h1>校园卡管理系统</h1>
   </div>
 <script language="javascript" type="text/javascript">
   var useRand = 0;
   images = new Array;
   images[1] = new Image();
   images[1].src = "15.jpg";
   
   images[2] = new Image();
   images[2].src = "14.jpg";
   
   images[3] = new Image();
   images[3].src = "13.jpg";
   
   function swapPic(){
       useRand=(useRand+1)%(images.length-1);
       if(useRand==0)
            useRand=3;
       document.randimg.src = images[useRand].src;	
       
       setTimeout('swapPic()',2000);
   }
   
 </script>
<div class="navbar">
  <a href="information.php">用户信息</a>
<!--   <a href="billmes.php">账单信息</a> -->
  <div class="dropdown">
    <button class="dropbtn">账单信息<i class="fa fa-caret-down"></i></button>
    <div class="dropdown-content">
      <a href="allbillmes.php">消费信息</a>
      <a href="allcharge_mess.php">充值信息</a>
    </div>
  </div>
 
  <a href="logout.php">退出登录</a>
  
</div>

  
 <img name ="randimg">
 <div class="footer">
    <h2>@该吃饺子了</h2>
  </div>
</body>
<ml>







</html>