<?php ob_start();?>
<?php
error_reporting(E_ERROR);
ini_set("display_errors","Off");
session_start();
$s_id='';
if(isset($_SESSION['username'])){
    $s_id=$_SESSION['username'];
}
?>
<?php
// 处理删除操作的页面
require "dbconfig.php";
// 连接mysql
$link = @mysqli_connect(HOST, USER, PASS, DBNAME) or die("ERROR: CANNOT CONNECT TO DATABASE!");
mysqli_set_charset($link,'utf8');
//  获取传递的餐时编号
$product_id = $_GET['product_id'];
$sql1 = mysqli_query($link, "SELECT * FROM food where product_id='$product_id'");  //根据餐时编号找对应信息
$data1=mysqli_fetch_assoc($sql1);

$product_name=$data1['product_name']; //餐时名称
$price=$data1['price']; //价格
$shangjia=$data1['shangjia']; //所购买的商家
$date=date('y-m-d h:i:s'); //当前时间

//获取用户信息
//$card_id='20021121';
$sql3 = mysqli_query($link, "SELECT * FROM students where s_id='$s_id'");  //根据餐时编号找对应信息
$result1=mysqli_fetch_assoc($sql3);
$card_id=$result1['card_id'];

//检查校园卡余额
$sql4 = mysqli_query($link, "SELECT * FROM card where s_id='$s_id'");
$result2=mysqli_fetch_assoc($sql4);
$r_sum=$result2['remaining_sum'];
$s=$result2['state'];
if($s==1)
    echo '<script>alert("校园卡状态异常!");parent.location.href="../Controller/food.php";</script>';
if($r_sum-$price<0)
    echo '<script>alert("校园卡余额不足!");parent.location.href="../Controller/food.php";</script>';
else
{
    //扣除余额
    $r_sum=$r_sum-$price;
    $sql5 = mysqli_query($link, "update card set remaining_sum='$r_sum' where s_id='$s_id'");
  
    
    //插入账单信息
    $sql = "INSERT INTO bill VALUES (NULL,'$card_id','$date','$product_name','$price','$shangjia','$r_sum')";
    mysqli_query($link, $sql);
    mysqli_close($link);
    echo '<script>alert("购买成功!");parent.location.href="../Controller/food.php";</script>';
    // header("Location:food.php");
}


ob_end_flush();
?>