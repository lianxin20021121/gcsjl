<?php ob_start();?>
<?php
session_start();

$clid="";
if(isset($_SESSION['username'])){
    $clid=$_SESSION['username'];
}
$user_id=$clid;
?>
<?php

// 数据库连接信息
$host = 'localhost';
$user = 'root';
$password = '123456';
$dbName = 'schoolcard';

// 建立数据库连接
$conn = new mysqli($host, $user, $password, $dbName);

// 检测连接是否成功
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 获取当前用户的ID

// 查询当前用户绑定的银行卡信息
$sql = "SELECT * FROM card_bind WHERE s_id = {$user_id}";
$result = $conn->query($sql);

// 输出绑定的银行卡信息
echo '<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>已绑定银行卡</title>
        <style type="text/css">
            body {
                background-image: url(1.jpg);
                background-size: cover;
            }
            table {
                border-collapse: collapse;
                margin: 50px auto;
                max-width: 800px;
                width: 90%;
            }
            th, td {
                padding: 12px;
                text-align: left;
                border: 1px solid black;
                font-size: 16px;
            }
            th {
                background-color: #4caf50;
                color: white;
            }
            td {
                background-color: white;
            }
            form {
                display: inline-block;
            }
            button[type=submit] {
                background-color: #4CAF50;
                color: white;
                padding: 8px 16px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                margin-right: 8px;
            }
            button[type=submit]:hover {
                background-color: #45a049;
            }
        </style>
    </head>
    <body>
        <table>
            <tr>
                <th>银行卡卡号</th>
                <th>银行卡类型</th>
                <th>余额（元）</th>
                <th>解绑</th>
            </tr>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>
                <td>' . $row['bankcard_id'] . '</td>
                <td>' . $row['bankcard_type'] . '</td>
                <td>' . $row['bankcard_money'] . '</td>
                <td>
                    <form action="card_unbind.php" method="POST">
                        <input type="hidden" name="bankcard_id" value="' . $row['bankcard_id'] . '">
                        <button type="submit">解绑</button>
                    </form>
                </td>
            </tr>';
    }
} else {
    echo '<tr><td colspan="4">暂无绑定银行卡</td></tr>';
}

echo '</table></body></html>';