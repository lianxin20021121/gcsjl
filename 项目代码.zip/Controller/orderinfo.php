<?php
session_start();
//$userid=$_SESSION['userid'];
include ('mysqli_connect.php');
$userid=200011;
?>

<?php

    $product_id = $_GET['product_id'];
    //if (confirm("确认购买?")) {
    //window.location = "buyfood.php?product_id=" + product_id;
    //从card表中查找card_id和remain_sum
    $sqla = "select card_id,remain_sum from card where s_id={$userid}";
    $resa = mysqli_query($dbc, $sqla);
    $resulta = mysqli_fetch_array($resa);

    //if ($resulta['remain_sum'] === 0) {
        echo "<script>alert('余额不足')</script>";
        echo "<meta http-equiv='Refresh' content=10; URL='oredr.php'>";
    //}


//从food中查找food所有信息
    $sqlb="SELECT * FROM food where product_id={$product_id}";
    $resb=mysqli_query($dbc, $sqlb);
    $result=mysqli_fetch_array($resb);

    //购买后需要将卡内的余额进行修改
    $tem = $resulta['remain_sum'] - $result['price'];

    $cardid=$resulta['card_id'];
    $pname=$result['product_name'];
    $price=$result['price'];
    $sj=$result['shangjia'];

    $sqld="update card set remain_sum='{$tem}' where card_id=$cardid";
    mysqli_query($dbc, $sqld);
    //插入账单信息
    $sqlc = "INSERT INTO bill VALUES (NULL,'{$cardid}',NOW(),'{$pname}','{$price}','{$sj}','{$tem}','{$userid}')";
    mysqli_query($dbc, $sqlc);
    mysqli_close($dbc);
    header("Location:order.php");
//}
?>