<?php ob_start();?>
<?php
session_start();
//$userid=$_SESSION['userid'];
include ('mysqli_connect.php');
//$clid=$_GET['id'];
$clid="";
if(isset($_SESSION['username'])){
    $clid=$_SESSION['username'];
}

$sqlb="select * from card where s_id={$clid}";
$resb=mysqli_query($dbc,$sqlb);
$resultb=mysqli_fetch_array($resb);

$sqly="select * from students where s_id={$clid}";
$resy=mysqli_query($dbc,$sqly);
$resulty=mysqli_fetch_array($resy);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="http://cdn.static.runoob.com/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>校园卡管理系统 || 修改密码</title>
    <style>
        body{
            background-image:url(1.jpg);
            background-size: cover;
            background-repeat: no-repeat;
        }
        .wrapper {width: 1100px;margin: 20px auto;}
        h2 {text-align: center;}

        .HOME {margin-bottom: 20px;}
        .HOME a {text-decoration: none;color: #fff;background-color: green;padding: 6px;border-radius: 5px;}

    </style>
</head>
<body>
<div class="wrapper">
    <div class="HOME">
        <a href="../Controller/page.php">主页面</a>
    </div>
</div>
<h1 style="text-align: center;color:navajowhite;font-size: 34px;padding-top: 2%;font-family: 华文楷体"><strong>修改密码</strong></h1>
<div style="padding: 10px 500px 10px;">
    <form   method="POST" style="text-align: center" class="bs-example bs-example-form" role="form">
        <div id="login">
            <div class="input-group"><span  class="input-group-addon">原始密码</span><input name="y_ps" type="text" placeholder="请输入原始密码" class="form-control"></div><br/>
            <div class="input-group"><span  class="input-group-addon">新密码</span><input  name="n_ps" type="text" placeholder="请输入新密码" class="form-control"></div><br/>
            <div class="input-group"><span  class="input-group-addon">确认密码</span><input  name="nre_ps" type="text" placeholder="请确认新密码" class="form-control"></div><br/>

            <label><input type="submit" value="确认修改" class="btn btn-default"></label>&nbsp &nbsp
            <label><input type="reset" value="重置" class="btn btn-default"></label>
        </div>
    </form>
</div>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST")
{

    $cps=$_POST['y_ps'];
    $nps = $_POST["n_ps"];
    $nreps = $_POST["nre_ps"];

    if($cps!=$resulty['password']){
        echo "<script>alert('初始密码错误，请重新输入！')</script>";
        echo "<script>window.location.href='password_edit.php'</script>";
    }
    if($nps!=$nreps){
        echo "<script>alert('两次输入新密码不一致，请重新输入！')</script>";
        echo "<script>window.location.href='password_edit.php'</script>";
    }
    if($cps==$resulty['password']&&$nps==$nreps){
        $sqla="update students set password='{$nps}' where s_id='{$clid}';";
        $resa=mysqli_query($dbc,$sqla);

        if (mysqli_query($dbc, $sqla)) {
            echo "<script>alert('密码修改成功！')</script>";
            echo "<script>window.location.href='personal_info.php'</script>";
        } else {
            echo "Error: " . $sqla . "<br>" . mysqli_error($dbc);
        }
    }
}
?>
</body>
</html>