<?php

// 数据库连接信息
$host = 'localhost';
$user = 'root';
$password = '123456';
$dbName = 'schoolcard';

// 建立数据库连接
$conn = new mysqli($host, $user, $password, $dbName);

// 检测连接是否成功
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 获取要解绑的银行卡ID
$bankcard_id = $_POST['bankcard_id'];

// 从数据库中删除银行卡信息
$sql = "DELETE FROM card_bind WHERE bankcard_id = {$bankcard_id}";
if ($conn->query($sql) === true) {
    echo "银行卡解绑成功";
} else {
    echo "出现错误，银行卡解绑失败： " . $conn->error;
}

// 关闭数据库连接
$conn->close();

?>